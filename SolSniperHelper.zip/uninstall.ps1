# SolSniper helper remover: undoes everything install.ps1 did.
$ErrorActionPreference = "SilentlyContinue"
Remove-Item -Path "HKCU:\Software\Classes\solsniper-join" -Recurse -Force
Remove-Item -Path (Join-Path $env:LOCALAPPDATA "SolSniperHelper") -Recurse -Force
Write-Host ""
Write-Host "SolSniper helper has been removed."
Read-Host "Press Enter to close"
