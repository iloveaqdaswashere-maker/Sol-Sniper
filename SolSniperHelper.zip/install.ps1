# SolSniper helper installer
# Copies join.ps1 into your user folder and teaches Windows the solsniper-join:// link.
# It only touches your own user account (no administrator rights needed).
$ErrorActionPreference = "Stop"
try {
    $source = Join-Path $PSScriptRoot "join.ps1"
    if (-not (Test-Path $source)) {
        Write-Host "join.ps1 must be in the same folder as this installer. Extract the whole zip first."
        Read-Host "Press Enter to close"
        exit 1
    }
    $dir = Join-Path $env:LOCALAPPDATA "SolSniperHelper"
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $script = Join-Path $dir "join.ps1"
    Copy-Item -Path $source -Destination $script -Force
    # a fresh install forgets the old pairing so SolSniper can pair again
    Remove-Item -Path (Join-Path $dir "token.txt") -Force -ErrorAction SilentlyContinue

    $key = "HKCU:\Software\Classes\solsniper-join"
    New-Item -Path $key -Force | Out-Null
    Set-ItemProperty -Path $key -Name "(Default)" -Value "URL:SolSniper Join"
    New-ItemProperty -Path $key -Name "URL Protocol" -Value "" -PropertyType String -Force | Out-Null
    $commandKey = $key + "\shell\open\command"
    New-Item -Path $commandKey -Force | Out-Null
    $command = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $script + '" "%1"'
    Set-ItemProperty -Path $commandKey -Name "(Default)" -Value $command

    Write-Host ""
    Write-Host "SolSniper helper is installed."
    Write-Host "Next: in SolSniper's Auto-join tab press Test helper. A small message box should appear."
    Write-Host ""
    Read-Host "Press Enter to close"
}
catch {
    Write-Host ("Something went wrong: " + $_.Exception.Message)
    Read-Host "Press Enter to close"
    exit 1
}
