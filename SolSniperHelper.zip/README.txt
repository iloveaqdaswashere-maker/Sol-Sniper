SolSniper helper
================

What it is
  A tiny add-on for SolSniper's "close Roblox first, then join" option. Some BetterDiscord versions do not let
  plugins close programs. With this helper, SolSniper opens a special link instead, and Windows hands it to a small
  script that closes Roblox and then opens the join link.

What it does (and nothing else)
  1. Checks the link carries your private pairing token (so a random website cannot use it).
  2. Checks the Roblox link is one of the exact shapes SolSniper makes (private server / share link).
  3. Closes the Roblox game window (the RobloxPlayerBeta process).
  4. Waits a moment, then opens the Roblox join link.
  It never downloads anything, never talks to the internet itself, and has no background process.

Install (once)
  1. Extract this whole zip into a folder (do not run it from inside the zip).
  2. Double-click Install.bat.
     If Windows says "Windows protected your PC", click More info, then Run anyway. That warning appears for any
     script you download. You can open join.ps1 and install.ps1 in Notepad first to read them.
  3. In SolSniper (Auto-join tab) press "Test helper". A small message box saying the helper is working should appear.
     If Windows asks which app to use instead, the install did not work.
  4. Tick "Use the helper when Roblox can't be closed directly".

Remove
  Double-click Uninstall.bat. It removes the link handler and the folder it created.

Good to know
  - Closing Roblox ends your current game at once. Unsaved progress in the game can be lost.
  - A black console window may flash for a moment when the helper runs.
  - Windows only. It does not cover the Microsoft Store version of Roblox.
  - Files it creates live in %LOCALAPPDATA%\SolSniperHelper
