# SolSniper helper
# Closes Roblox, then opens the Roblox join link that SolSniper asked for.
# It is plain text: you can read everything it does. It only accepts solsniper-join:// links
# that carry your private pairing token, and it only opens roblox:// links of the exact shapes below.
param([string]$Link)

$ErrorActionPreference = "Stop"
$dir = Join-Path $env:LOCALAPPDATA "SolSniperHelper"
$tokenFile = Join-Path $dir "token.txt"
$stampFile = Join-Path $dir "last.txt"

function Say($text) {
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show($text, "SolSniper helper") | Out-Null
}

try {
    $prefix = "solsniper-join://"
    if (-not $Link) { exit }
    if ($Link.Length -gt 1000) { exit }
    if (-not $Link.StartsWith($prefix)) { exit }

    $rest = $Link.Substring($prefix.Length)
    $parts = $rest -split "\?", 2
    $action = $parts[0].Trim("/")
    $query = ""
    if ($parts.Length -gt 1) { $query = $parts[1] }

    $params = @{}
    foreach ($pair in ($query -split "&")) {
        $kv = $pair -split "=", 2
        if ($kv.Length -eq 2) { $params[$kv[0]] = [System.Uri]::UnescapeDataString($kv[1]) }
    }

    # the pairing token: the first one this helper sees is remembered, and only that one is accepted after
    $token = $params["t"]
    if ($token -notmatch '^[A-Za-z0-9]{16,64}$') { exit }
    if (Test-Path $tokenFile) {
        $saved = (Get-Content -Path $tokenFile -Raw).Trim()
        if ($saved -ne $token) {
            Say "This request did not come from your SolSniper (pairing token mismatch). Nothing was done. If you reinstalled SolSniper, run Install.bat from the helper folder again."
            exit
        }
    } else {
        Set-Content -Path $tokenFile -Value $token
    }

    if ($action -eq "test") {
        Say "SolSniper helper is working. Nothing was closed or opened."
        exit
    }
    if ($action -ne "join") { exit }

    # only these exact roblox:// shapes are ever opened
    $uri = $params["u"]
    $allowed = ($uri -match '^roblox://placeId=\d{1,20}&linkCode=[A-Za-z0-9_%.-]{1,120}$') -or
               ($uri -match '^roblox://placeId=\d{1,20}&gameInstanceId=[A-Za-z0-9_%.-]{1,120}$') -or
               ($uri -match '^roblox://navigation/share_links\?code=[A-Za-z0-9_%.-]{1,120}&type=Server$')
    if (-not $allowed) { exit }

    # ignore requests that arrive less than 3 seconds after the previous one
    if (Test-Path $stampFile) {
        $age = ((Get-Date) - (Get-Item -Path $stampFile).LastWriteTime).TotalSeconds
        if ($age -lt 3) { exit }
    }
    Set-Content -Path $stampFile -Value "x"

    $running = Get-Process -Name "RobloxPlayerBeta" -ErrorAction SilentlyContinue
    if ($running) {
        $running | Stop-Process -Force -ErrorAction SilentlyContinue
        for ($i = 0; $i -lt 20; $i++) {
            if (-not (Get-Process -Name "RobloxPlayerBeta" -ErrorAction SilentlyContinue)) { break }
            Start-Sleep -Milliseconds 250
        }
        Start-Sleep -Milliseconds 1000
    }
    Start-Process $uri
}
catch {
    Say ("SolSniper helper hit a problem: " + $_.Exception.Message)
}
